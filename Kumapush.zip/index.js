const URLkumapush = ""


const request = require('request');
request(URLkumapush).on('error', function(err) {
    console.error(err)
  });;

setInterval(loop, 60000);


function loop(){
    request(URLkumapush).on('error', function(err) {
        console.error(err)
      });;
}
